import { useState, useEffect } from 'react';
import {
  listRepoContents,
  getRawUrl,
  getFileIcon,
  formatSize,
  isImage,
  isVideo,
  type RepoFile,
} from '../services/repoBrowser';

interface Props {
  token: string;
  fullName: string;
  branch: string;
  onClose: () => void;
}

export default function RepoBrowser({ token, fullName, branch, onClose }: Props) {
  const [currentPath, setCurrentPath] = useState('');
  const [files, setFiles] = useState<RepoFile[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState('');
  const [previewFile, setPreviewFile] = useState<RepoFile | null>(null);

  useEffect(() => {
    loadFiles(currentPath);
  }, [currentPath]);

  const loadFiles = async (path: string) => {
    setLoading(true);
    setError('');
    try {
      const contents = await listRepoContents(token, fullName, path);
      // Ordenar: pastas primeiro, depois arquivos
      const sorted = contents.sort((a, b) => {
        if (a.type === 'dir' && b.type !== 'dir') return -1;
        if (a.type !== 'dir' && b.type === 'dir') return 1;
        return a.name.localeCompare(b.name);
      });
      setFiles(sorted);
    } catch (e: any) {
      setError(e.message || 'Erro ao carregar arquivos');
    } finally {
      setLoading(false);
    }
  };

  const navigateTo = (file: RepoFile) => {
    if (file.type === 'dir') {
      setCurrentPath(file.path);
    } else {
      setPreviewFile(file);
    }
  };

  const goUp = () => {
    if (!currentPath) return;
    const parts = currentPath.split('/');
    parts.pop();
    setCurrentPath(parts.join('/'));
  };

  const copyUrl = (file: RepoFile) => {
    const url = getRawUrl(fullName, branch, file.path);
    navigator.clipboard.writeText(url);
    setCopied(file.path);
    setTimeout(() => setCopied(''), 2000);
  };

  const breadcrumbs = currentPath ? currentPath.split('/') : [];

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="bg-gray-800 border border-gray-700 rounded-2xl max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl">
        {/* Header */}
        <div className="border-b border-gray-700 p-4 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center">
              <i className="fas fa-folder-open text-white"></i>
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Arquivos do Repositório</h2>
              <p className="text-xs text-gray-400">{fullName}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-gray-700 hover:bg-gray-600 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
          >
            <i className="fas fa-times"></i>
          </button>
        </div>

        {/* Breadcrumbs */}
        <div className="border-b border-gray-700 px-4 py-2 flex items-center gap-2 text-sm flex-shrink-0 overflow-x-auto">
          <button
            onClick={() => setCurrentPath('')}
            className="text-gray-400 hover:text-white transition-colors flex items-center gap-1 flex-shrink-0"
          >
            <i className="fas fa-home text-xs"></i>
            <span>root</span>
          </button>
          {breadcrumbs.map((crumb, i) => (
            <div key={i} className="flex items-center gap-2 flex-shrink-0">
              <i className="fas fa-chevron-right text-gray-600 text-xs"></i>
              <button
                onClick={() => setCurrentPath(breadcrumbs.slice(0, i + 1).join('/'))}
                className="text-gray-400 hover:text-white transition-colors"
              >
                {crumb}
              </button>
            </div>
          ))}
        </div>

        {/* Error */}
        {error && (
          <div className="mx-4 mt-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg flex items-center gap-2">
            <i className="fas fa-exclamation-circle text-red-400"></i>
            <span className="text-red-300 text-sm">{error}</span>
          </div>
        )}

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4">
          {loading ? (
            <div className="flex items-center justify-center py-12">
              <i className="fas fa-spinner fa-spin text-2xl text-gray-400"></i>
            </div>
          ) : files.length === 0 ? (
            <div className="text-center py-12">
              <i className="fas fa-folder-open text-4xl text-gray-600 mb-3"></i>
              <p className="text-gray-500">Pasta vazia</p>
            </div>
          ) : (
            <div className="space-y-1">
              {/* Botão voltar */}
              {currentPath && (
                <button
                  onClick={goUp}
                  className="w-full p-3 flex items-center gap-3 hover:bg-gray-700/30 rounded-lg transition-colors group"
                >
                  <i className="fas fa-arrow-up text-gray-500 group-hover:text-white"></i>
                  <span className="text-sm text-gray-400 group-hover:text-white">..</span>
                </button>
              )}

              {/* Lista de arquivos */}
              {files.map((file) => (
                <div
                  key={file.path}
                  className="p-3 flex items-center gap-3 hover:bg-gray-700/30 rounded-lg transition-colors group"
                >
                  <button
                    onClick={() => navigateTo(file)}
                    className="flex-1 flex items-center gap-3 text-left"
                  >
                    <i className={`fas ${getFileIcon(file.name, file.type)} w-5`}></i>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm text-white truncate">{file.name}</p>
                      {file.type === 'file' && (
                        <p className="text-xs text-gray-500">{formatSize(file.size)}</p>
                      )}
                    </div>
                  </button>

                  {/* Botão copiar URL (só para arquivos) */}
                  {file.type === 'file' && file.download_url && (
                    <button
                      onClick={() => copyUrl(file)}
                      className="px-3 py-1.5 text-xs bg-gray-700 hover:bg-emerald-500 text-gray-300 hover:text-white rounded-lg transition-all flex items-center gap-1.5 opacity-0 group-hover:opacity-100"
                      title="Copiar URL"
                    >
                      {copied === file.path ? (
                        <>
                          <i className="fas fa-check"></i> Copiado!
                        </>
                      ) : (
                        <>
                          <i className="fas fa-copy"></i> Copiar URL
                        </>
                      )}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Preview Modal */}
        {previewFile && (
          <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
            <div className="bg-gray-800 border border-gray-700 rounded-2xl max-w-3xl w-full max-h-[90vh] flex flex-col shadow-2xl">
              <div className="border-b border-gray-700 p-4 flex items-center justify-between flex-shrink-0">
                <div className="flex items-center gap-3 min-w-0">
                  <i className={`fas ${getFileIcon(previewFile.name, 'file')} text-xl`}></i>
                  <div className="min-w-0">
                    <p className="text-white font-medium truncate">{previewFile.name}</p>
                    <p className="text-xs text-gray-400">{formatSize(previewFile.size)}</p>
                  </div>
                </div>
                <button
                  onClick={() => setPreviewFile(null)}
                  className="w-8 h-8 rounded-lg bg-gray-700 hover:bg-gray-600 flex items-center justify-center text-gray-400 hover:text-white transition-colors flex-shrink-0"
                >
                  <i className="fas fa-times"></i>
                </button>
              </div>

              <div className="flex-1 overflow-auto p-4">
                {/* Preview de imagem */}
                {isImage(previewFile.name) && previewFile.download_url && (
                  <div className="flex items-center justify-center">
                    <img
                      src={previewFile.download_url}
                      alt={previewFile.name}
                      className="max-w-full max-h-[60vh] rounded-lg"
                    />
                  </div>
                )}

                {/* Preview de vídeo */}
                {isVideo(previewFile.name) && previewFile.download_url && (
                  <div className="flex items-center justify-center">
                    <video
                      src={previewFile.download_url}
                      controls
                      className="max-w-full max-h-[60vh] rounded-lg"
                    />
                  </div>
                )}

                {/* URL para copiar */}
                <div className="mt-6 p-4 bg-gray-900/50 rounded-xl">
                  <p className="text-xs text-gray-400 mb-2">
                    <i className="fas fa-link mr-1"></i> URL para usar no seu site:
                  </p>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      readOnly
                      value={previewFile.download_url || ''}
                      className="flex-1 bg-gray-800 border border-gray-600 rounded-lg px-3 py-2 text-sm text-white font-mono"
                      onClick={(e) => (e.target as HTMLInputElement).select()}
                    />
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(previewFile.download_url || '');
                        setCopied('url');
                        setTimeout(() => setCopied(''), 2000);
                      }}
                      className="px-4 py-2 bg-emerald-500 hover:bg-emerald-400 rounded-lg text-sm font-medium transition-all flex items-center gap-2"
                    >
                      {copied === 'url' ? (
                        <>
                          <i className="fas fa-check"></i> Copiado!
                        </>
                      ) : (
                        <>
                          <i className="fas fa-copy"></i> Copiar
                        </>
                      )}
                    </button>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">
                    <i className="fas fa-info-circle mr-1"></i>
                    Use essa URL no código HTML: <code className="text-cyan-400">&lt;img src="URL_AQUI" /&gt;</code>
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="border-t border-gray-700 p-4 flex justify-between items-center flex-shrink-0">
          <p className="text-xs text-gray-500">
            <i className="fas fa-lightbulb text-yellow-400 mr-1"></i>
            Clique em um arquivo para ver preview e copiar a URL
          </p>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-gray-700 hover:bg-gray-600 rounded-lg text-sm font-medium transition-all"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}
