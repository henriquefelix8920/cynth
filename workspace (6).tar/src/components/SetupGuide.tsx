import { useState } from 'react';

interface Props {
  onClose: () => void;
}

export default function SetupGuide({ onClose }: Props) {
  const [copied, setCopied] = useState('');

  const copy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(''), 2000);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="bg-gray-800 border border-gray-700 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl">
        {/* Header */}
        <div className="sticky top-0 bg-gray-800 border-b border-gray-700 p-6 flex items-center justify-between rounded-t-2xl z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-400 to-cyan-500 flex items-center justify-center">
              <i className="fas fa-book-open text-white"></i>
            </div>
            <div>
              <h2 className="text-lg font-bold text-white">Como Instalar o AutoDeploy</h2>
              <p className="text-xs text-gray-400">Guia rápido em 4 passos</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg bg-gray-700 hover:bg-gray-600 flex items-center justify-center text-gray-400 hover:text-white transition-colors"
          >
            <i className="fas fa-times"></i>
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Passo 1 */}
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm">
              1
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-white mb-2">Criar o Repositório no GitHub</h3>
              <p className="text-sm text-gray-400 mb-3">
                Crie um novo repositório público no GitHub (ex: <code className="text-cyan-400 bg-gray-900 px-1.5 py-0.5 rounded">autodeploy</code>)
              </p>
              <div className="bg-gray-900/50 rounded-lg p-3 text-xs text-gray-400">
                <i className="fas fa-lightbulb text-yellow-400 mr-1"></i>
                Dica: Não precisa inicializar com README. O Vercel vai subir os arquivos pra você.
              </div>
            </div>
          </div>

          {/* Passo 2 */}
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm">
              2
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-white mb-2">Subir os Arquivos no GitHub</h3>
              <p className="text-sm text-gray-400 mb-3">
                Vá no repositório criado → clique em <strong>"uploading an existing file"</strong> → arraste todos os arquivos deste projeto (a pasta inteira que você baixou).
              </p>
              <div className="bg-gray-900/50 rounded-lg p-3">
                <p className="text-xs text-gray-400 mb-2">
                  <i className="fas fa-folder-open text-emerald-400 mr-1"></i>
                  Arquivos que você precisa subir:
                </p>
                <div className="grid grid-cols-2 gap-1 text-xs">
                  {['index.html', 'package.json', 'vite.config.ts', 'tsconfig.json', 'src/', 'public/', 'tailwind.config.js', 'postcss.config.js'].map((f) => (
                    <div key={f} className="flex items-center gap-1.5 text-gray-300">
                      <i className={`fas ${f.endsWith('/') ? 'fa-folder text-yellow-400' : 'fa-file-code text-cyan-400'} text-[10px]`}></i>
                      {f}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Passo 3 */}
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm">
              3
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-white mb-2">Fazer Deploy na Vercel</h3>
              <p className="text-sm text-gray-400 mb-3">
                Acesse{' '}
                <a href="https://vercel.com/new" target="_blank" className="text-emerald-400 hover:underline">
                  vercel.com/new
                </a>{' '}
                → Importe o repositório que você criou → Clique em <strong>"Deploy"</strong>.
              </p>
              <div className="bg-gray-900/50 rounded-lg p-3 space-y-2">
                <p className="text-xs text-gray-400">
                  <i className="fas fa-cog text-gray-500 mr-1"></i>
                  Configurações automáticas (a Vercel detecta Vite):
                </p>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-gray-800 rounded p-2">
                    <span className="text-gray-500">Framework:</span>{' '}
                    <span className="text-white">Vite</span>
                  </div>
                  <div className="bg-gray-800 rounded p-2">
                    <span className="text-gray-500">Build:</span>{' '}
                    <span className="text-white">npm run build</span>
                  </div>
                  <div className="bg-gray-800 rounded p-2">
                    <span className="text-gray-500">Output:</span>{' '}
                    <span className="text-white">dist</span>
                  </div>
                  <div className="bg-gray-800 rounded p-2">
                    <span className="text-gray-500">Node:</span>{' '}
                    <span className="text-white">18+</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Passo 4 */}
          <div className="flex gap-4">
            <div className="flex-shrink-0 w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm">
              4
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-white mb-2">Criar o Token do GitHub</h3>
              <p className="text-sm text-gray-400 mb-3">
                Para o AutoDeploy funcionar, você precisa de um Personal Access Token:
              </p>
              <div className="bg-gray-900/50 rounded-lg p-3 space-y-2">
                <ol className="text-xs text-gray-400 space-y-1.5 list-decimal list-inside">
                  <li>
                    Acesse{' '}
                    <a
                      href="https://github.com/settings/tokens/new"
                      target="_blank"
                      className="text-emerald-400 hover:underline"
                    >
                      github.com/settings/tokens/new
                    </a>
                  </li>
                  <li>
                    Dê um nome: <code className="text-cyan-400 bg-gray-800 px-1 rounded">autodeploy</code>
                  </li>
                  <li>
                    Marque as permissões:{' '}
                    <code className="text-cyan-400 bg-gray-800 px-1 rounded">repo</code> (toda a seção)
                  </li>
                  <li>Clique em "Generate token"</li>
                  <li>Copie o token (começa com <code className="text-cyan-400">ghp_...</code>)</li>
                </ol>
              </div>
            </div>
          </div>

          {/* Pronto */}
          <div className="bg-gradient-to-r from-emerald-500/10 to-cyan-500/10 border border-emerald-500/30 rounded-xl p-4">
            <div className="flex items-center gap-3">
              <i className="fas fa-check-circle text-emerald-400 text-xl"></i>
              <div>
                <p className="text-sm font-semibold text-white">Pronto!</p>
                <p className="text-xs text-gray-400">
                  Após o deploy na Vercel, acesse a URL gerada (ex: autodeploy.vercel.app), cole seu token e comece a publicar seus sites!
                </p>
              </div>
            </div>
          </div>

          {/* Alternativa: GitHub Pages */}
          <div className="bg-gray-900/30 border border-gray-700/50 rounded-xl p-4">
            <p className="text-sm text-gray-300 mb-2">
              <i className="fas fa-lightbulb text-yellow-400 mr-1"></i>
              <strong>Alternativa sem Vercel:</strong> Você também pode hospedar no próprio GitHub Pages!
            </p>
            <p className="text-xs text-gray-500">
              Basta fazer push dos arquivos → Settings → Pages → Source: GitHub Actions → Selecionar o workflow de Node.js.
              A URL será: <code className="text-cyan-400">seu-usuario.github.io/nome-do-repo</code>
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 bg-gray-800 border-t border-gray-700 p-4 flex justify-between items-center rounded-b-2xl">
          <p className="text-xs text-gray-500">
            <i className="fas fa-shield-alt mr-1"></i>
            Seu token fica salvo apenas no seu navegador
          </p>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 rounded-lg text-sm font-medium transition-all"
          >
            Entendi, vamos lá!
          </button>
        </div>
      </div>
    </div>
  );
}
