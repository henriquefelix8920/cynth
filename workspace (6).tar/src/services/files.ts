import JSZip from 'jszip';
import type { FileEntry } from './github';

// Arquivos/diretórios que devem ser ignorados
const IGNORE_PATTERNS = [
  'node_modules',
  '.git',
  '.DS_Store',
  'Thumbs.db',
  '__pycache__',
  '.env',
  '.env.local',
  '.env.production',
  '.vercel',
  'dist',
  'build',
];

function shouldIgnore(path: string): boolean {
  const parts = path.split('/');
  return parts.some((part) =>
    IGNORE_PATTERNS.some((pattern) => part === pattern || part.startsWith('.env.'))
  );
}

export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      // Remove o prefixo data:...;base64,
      const base64 = result.split(',')[1];
      resolve(base64);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export async function processFiles(files: File[]): Promise<FileEntry[]> {
  const entries: FileEntry[] = [];

  for (const file of files) {
    const relativePath = file.webkitRelativePath || file.name;

    // Remover prefixo de pasta raiz se existir
    let path = relativePath;
    const firstSlash = path.indexOf('/');
    if (firstSlash !== -1) {
      path = path.substring(firstSlash + 1);
    }

    if (!path || shouldIgnore(path)) continue;

    const base64 = await fileToBase64(file);
    entries.push({ path, content: base64, encoding: 'base64' });
  }

  return entries;
}

export async function processZip(file: File): Promise<FileEntry[]> {
  const zip = new JSZip();
  const loaded = await zip.loadAsync(file);
  const entries: FileEntry[] = [];

  const promises: Promise<void>[] = [];

  loaded.forEach((relativePath, zipEntry) => {
    if (zipEntry.dir) return;
    if (shouldIgnore(relativePath)) return;
    if (!relativePath || relativePath.startsWith('__MACOSX')) return;

    // Remover primeira pasta se for só um wrapper
    let cleanPath = relativePath;
    const parts = cleanPath.split('/');
    // Se todos os arquivos estão dentro de uma única pasta raiz, remover
    const firstFolder = parts[0];
    const allInSameFolder = Object.keys(loaded.files).every((p) => {
      const pParts = p.split('/');
      return pParts[0] === firstFolder || p === firstFolder + '/';
    });

    if (allInSameFolder && parts.length > 1) {
      cleanPath = parts.slice(1).join('/');
    }

    if (!cleanPath) return;

    const promise = zipEntry.async('base64').then((base64) => {
      entries.push({ path: cleanPath, content: base64, encoding: 'base64' });
    });
    promises.push(promise);
  });

  await Promise.all(promises);
  return entries;
}

export function formatFileSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function getTotalSize(files: FileEntry[]): number {
  return files.reduce((acc, f) => acc + (f.content.length * 3) / 4, 0);
}
