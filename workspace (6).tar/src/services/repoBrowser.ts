export interface RepoFile {
  name: string;
  path: string;
  type: 'file' | 'dir';
  size: number;
  download_url: string | null;
  sha: string;
}

const API = 'https://api.github.com';

function headers(token: string) {
  return {
    Authorization: `Bearer ${token}`,
    Accept: 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
  };
}

export async function listRepoContents(
  token: string,
  fullName: string,
  path: string = ''
): Promise<RepoFile[]> {
  const url = path
    ? `${API}/repos/${fullName}/contents/${path}`
    : `${API}/repos/${fullName}/contents`;

  const res = await fetch(url, { headers: headers(token) });
  if (!res.ok) throw new Error('Erro ao listar arquivos do repositório');
  return res.json();
}

export async function getFileContent(
  token: string,
  fullName: string,
  path: string
): Promise<string> {
  const res = await fetch(`${API}/repos/${fullName}/contents/${path}`, {
    headers: headers(token),
  });
  if (!res.ok) throw new Error('Erro ao ler arquivo');
  const data = await res.json();
  if (data.encoding === 'base64') {
    return atob(data.content);
  }
  return data.content;
}

export function getRawUrl(fullName: string, branch: string, path: string): string {
  return `https://raw.githubusercontent.com/${fullName}/${branch}/${path}`;
}

export function getFileExtension(filename: string): string {
  const parts = filename.split('.');
  return parts.length > 1 ? parts.pop()?.toLowerCase() || '' : '';
}

export function isImage(filename: string): boolean {
  const ext = getFileExtension(filename);
  return ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp', 'ico'].includes(ext);
}

export function isVideo(filename: string): boolean {
  const ext = getFileExtension(filename);
  return ['mp4', 'webm', 'ogg', 'mov', 'avi'].includes(ext);
}

export function isAudio(filename: string): boolean {
  const ext = getFileExtension(filename);
  return ['mp3', 'wav', 'ogg', 'm4a', 'aac'].includes(ext);
}

export function getFileIcon(filename: string, type: 'file' | 'dir'): string {
  if (type === 'dir') return 'fa-folder text-yellow-400';
  if (isImage(filename)) return 'fa-image text-purple-400';
  if (isVideo(filename)) return 'fa-video text-pink-400';
  if (isAudio(filename)) return 'fa-music text-blue-400';
  const ext = getFileExtension(filename);
  if (['html', 'htm'].includes(ext)) return 'fa-code text-orange-400';
  if (['css'].includes(ext)) return 'fa-paint-brush text-blue-400';
  if (['js', 'ts', 'jsx', 'tsx'].includes(ext)) return 'fa-file-code text-yellow-400';
  if (['json'].includes(ext)) return 'fa-file-code text-green-400';
  if (['md'].includes(ext)) return 'fa-file-alt text-gray-400';
  return 'fa-file text-gray-400';
}

export function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
