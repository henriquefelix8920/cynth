export interface GitHubUser {
  login: string;
  avatar_url: string;
  name: string;
}

export interface GitHubRepo {
  id: number;
  name: string;
  full_name: string;
  private: boolean;
  html_url: string;
  default_branch: string;
  has_pages: boolean;
  description: string;
  updated_at: string;
}

export interface FileEntry {
  path: string;
  content: string; // base64
  encoding: 'base64';
}

const API = 'https://api.github.com';

function headers(token: string) {
  return {
    Authorization: `Bearer ${token}`,
    Accept: 'application/vnd.github+json',
    'X-GitHub-Api-Version': '2022-11-28',
  };
}

export async function getUser(token: string): Promise<GitHubUser> {
  const res = await fetch(`${API}/user`, { headers: headers(token) });
  if (!res.ok) throw new Error('Token inválido ou expirado');
  return res.json();
}

export async function listRepos(token: string, page = 1, perPage = 30): Promise<GitHubRepo[]> {
  const res = await fetch(
    `${API}/user/repos?sort=updated&per_page=${perPage}&page=${page}&type=owner`,
    { headers: headers(token) }
  );
  if (!res.ok) throw new Error('Erro ao listar repositórios');
  return res.json();
}

export async function createRepo(
  token: string,
  name: string,
  description: string,
  isPrivate: boolean
): Promise<GitHubRepo> {
  const res = await fetch(`${API}/user/repos`, {
    method: 'POST',
    headers: { ...headers(token), 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name,
      description,
      private: isPrivate,
      auto_init: true,
    }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.message || 'Erro ao criar repositório');
  }
  return res.json();
}

export async function getRepoBranches(token: string, fullName: string): Promise<string[]> {
  const res = await fetch(`${API}/repos/${fullName}/branches`, {
    headers: headers(token),
  });
  if (!res.ok) throw new Error('Erro ao listar branches');
  const branches = await res.json();
  return branches.map((b: { name: string }) => b.name);
}

export async function enablePages(
  token: string,
  fullName: string,
  branch: string
): Promise<void> {
  const res = await fetch(`${API}/repos/${fullName}/pages`, {
    method: 'POST',
    headers: { ...headers(token), 'Content-Type': 'application/json' },
    body: JSON.stringify({
      build_type: 'workflow',
      source: {
        branch,
        path: '/',
      },
    }),
  });
  // Pode falhar se já estiver habilitado, tudo bem
  if (!res.ok && res.status !== 409) {
    // Tenta com legacy source
    const res2 = await fetch(`${API}/repos/${fullName}/pages`, {
      method: 'POST',
      headers: { ...headers(token), 'Content-Type': 'application/json' },
      body: JSON.stringify({
        source: {
          branch,
          path: '/',
        },
      }),
    });
    if (!res2.ok && res2.status !== 409) {
      console.warn('Não foi possível habilitar GitHub Pages automaticamente');
    }
  }
}

// Deploy usando Git Data API (mais eficiente para múltiplos arquivos)
export async function deployFiles(
  token: string,
  fullName: string,
  branch: string,
  files: FileEntry[],
  message: string = 'Deploy automático via AutoDeploy'
): Promise<{ commitSha: string; filesCount: number }> {
  // 1. Pegar o commit atual da branch
  const refRes = await fetch(`${API}/repos/${fullName}/git/ref/heads/${branch}`, {
    headers: headers(token),
  });
  if (!refRes.ok) throw new Error(`Branch "${branch}" não encontrada`);
  const refData = await refRes.json();
  const latestCommitSha = refData.object.sha;

  // 2. Pegar o tree do commit
  const commitRes = await fetch(
    `${API}/repos/${fullName}/git/commits/${latestCommitSha}`,
    { headers: headers(token) }
  );
  if (!commitRes.ok) throw new Error('Erro ao ler commit atual');
  const commitData = await commitRes.json();
  const baseTreeSha = commitData.tree.sha;

  // 3. Criar blobs para cada arquivo
  const treeItems = [];
  const BATCH_SIZE = 50;

  for (let i = 0; i < files.length; i += BATCH_SIZE) {
    const batch = files.slice(i, i + BATCH_SIZE);
    const blobPromises = batch.map(async (file) => {
      const blobRes = await fetch(`${API}/repos/${fullName}/git/blobs`, {
        method: 'POST',
        headers: { ...headers(token), 'Content-Type': 'application/json' },
        body: JSON.stringify({
          content: file.content,
          encoding: file.encoding,
        }),
      });
      if (!blobRes.ok) throw new Error(`Erro ao criar blob para ${file.path}`);
      const blobData = await blobRes.json();
      return {
        path: file.path,
        mode: '100644' as const,
        type: 'blob' as const,
        sha: blobData.sha,
      };
    });
    const items = await Promise.all(blobPromises);
    treeItems.push(...items);
  }

  // 4. Criar novo tree
  const treeRes = await fetch(`${API}/repos/${fullName}/git/trees`, {
    method: 'POST',
    headers: { ...headers(token), 'Content-Type': 'application/json' },
    body: JSON.stringify({
      base_tree: baseTreeSha,
      tree: treeItems,
    }),
  });
  if (!treeRes.ok) throw new Error('Erro ao criar tree');
  const treeData = await treeRes.json();

  // 5. Criar commit
  const newCommitRes = await fetch(`${API}/repos/${fullName}/git/commits`, {
    method: 'POST',
    headers: { ...headers(token), 'Content-Type': 'application/json' },
    body: JSON.stringify({
      message,
      tree: treeData.sha,
      parents: [latestCommitSha],
    }),
  });
  if (!newCommitRes.ok) throw new Error('Erro ao criar commit');
  const newCommitData = await newCommitRes.json();

  // 6. Atualizar ref da branch
  const updateRefRes = await fetch(
    `${API}/repos/${fullName}/git/refs/heads/${branch}`,
    {
      method: 'PATCH',
      headers: { ...headers(token), 'Content-Type': 'application/json' },
      body: JSON.stringify({
        sha: newCommitData.sha,
      }),
    }
  );
  if (!updateRefRes.ok) throw new Error('Erro ao atualizar branch');

  return { commitSha: newCommitData.sha, filesCount: files.length };
}

export async function deleteFiles(
  token: string,
  fullName: string,
  branch: string,
  filePaths: string[],
  message: string = 'Remoção de arquivos via AutoDeploy'
): Promise<void> {
  if (filePaths.length === 0) return;

  const refRes = await fetch(`${API}/repos/${fullName}/git/ref/heads/${branch}`, {
    headers: headers(token),
  });
  if (!refRes.ok) throw new Error(`Branch "${branch}" não encontrada`);
  const refData = await refRes.json();
  const latestCommitSha = refData.object.sha;

  const commitRes = await fetch(
    `${API}/repos/${fullName}/git/commits/${latestCommitSha}`,
    { headers: headers(token) }
  );
  if (!commitRes.ok) throw new Error('Erro ao ler commit');
  const commitData = await commitRes.json();
  const baseTreeSha = commitData.tree.sha;

  const treeItems = filePaths.map((path) => ({
    path,
    mode: '100644' as const,
    type: 'blob' as const,
    sha: null, // null = deletar
  }));

  const treeRes = await fetch(`${API}/repos/${fullName}/git/trees`, {
    method: 'POST',
    headers: { ...headers(token), 'Content-Type': 'application/json' },
    body: JSON.stringify({
      base_tree: baseTreeSha,
      tree: treeItems,
    }),
  });
  if (!treeRes.ok) throw new Error('Erro ao criar tree');
  const treeData = await treeRes.json();

  const newCommitRes = await fetch(`${API}/repos/${fullName}/git/commits`, {
    method: 'POST',
    headers: { ...headers(token), 'Content-Type': 'application/json' },
    body: JSON.stringify({
      message,
      tree: treeData.sha,
      parents: [latestCommitSha],
    }),
  });
  if (!newCommitRes.ok) throw new Error('Erro ao criar commit');
  const newCommitData = await newCommitRes.json();

  await fetch(`${API}/repos/${fullName}/git/refs/heads/${branch}`, {
    method: 'PATCH',
    headers: { ...headers(token), 'Content-Type': 'application/json' },
    body: JSON.stringify({ sha: newCommitData.sha }),
  });
}
